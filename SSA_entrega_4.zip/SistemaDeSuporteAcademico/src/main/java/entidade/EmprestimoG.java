package entidade;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.validation.constraints.Future;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import org.hibernate.validator.constraints.NotBlank;

@Entity
@Table(name = "TB_EMPRESTIMO")
@Access(AccessType.FIELD)
@NamedQueries(
        {
            @NamedQuery(
                    name = EmprestimoG.EMPRESTIMO_POR_STATUS,
                    query = "SELECT e FROM EmprestimoG e WHERE e.status = ?1"
            ),
            @NamedQuery(
                    name = EmprestimoG.EMPRESTIMOS,
                    query = "SELECT e FROM EmprestimoG e ORDER BY e.id"
            ),
             @NamedQuery(
                    name = EmprestimoG.EMPRESTIMO_POR_ID,
                    query = "SELECT e FROM EmprestimoG e WHERE e.id = ?1"
            ),
             @NamedQuery(
                    name = EmprestimoG.EMPRESTIMO_POR_ID_DE_USUARIO,
                    query = "SELECT e FROM EmprestimoG e WHERE e.usuario.id = ?1"
            )
        }
)
public class EmprestimoG extends Entidade implements Serializable {

    public static final String EMPRESTIMO_POR_STATUS = "EmprestimoPorStatus";
    public static final String EMPRESTIMOS = "Emprestimos";
    public static final String EMPRESTIMO_POR_ID = "EmprestimoPorId";
    public static final String EMPRESTIMO_POR_ID_DE_USUARIO = "EmprestimoPorIdDeUsuario";
    
//    @Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
//    @Column(name = "id_emprestimo")
//    private Long idEmprestimo;

    @Column(name = "data_entrega")
//    @Temporal(javax.persistence.TemporalType.DATE)
//    private Date dataEntrega;
    private String dataEntrega;

//    @Future(message="{Emprestimo.dataDevolucao}")
    @Column(name = "data_devolucao")
//    @Temporal(javax.persistence.TemporalType.DATE)
//    private Date dataDevolucao;
    private String dataDevolucao;

    @NotBlank(message="{Emprestimo.status}")
    @Column(name = "status")
    private String status;

    //Cardinalidade Usuario 1 : N EmprestimoG
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
//    @JoinColumn(name = "id_usuario", referencedColumnName = "id_usuario")
    @JoinColumn(name = "id_usuario", referencedColumnName = "id")
    protected UsuarioG usuario;

    //Cardinalidade Livro 1 : N EmprestimoG
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "id_livro", referencedColumnName = "id")
    protected LivroG livro;

//    public Long getIdEmprestimo() {
//        return this.idEmprestimo;
//    }
//
//    public void setIdEmprestimo(Long idEmprestimo) {
//        this.idEmprestimo = idEmprestimo;
//    }

    public String getDataEntrega() {
        return this.dataEntrega;
    }

    public void setDataEntrega(String dataEntrega) {
        this.dataEntrega = dataEntrega;
    }

    public String getDataDevolucao() {
        return this.dataDevolucao;
    }

    public void setDataDevolucao(String dataDevolucao) {
        this.dataDevolucao = dataDevolucao;
    }

    public String getStatus() {
        return this.status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public LivroG getLivro() {
        return this.livro;
    }

    public void setLivro(LivroG livro) {
        this.livro = livro;
    }

    public UsuarioG getUsuario() {
        return this.usuario;
    }

    public void setUsuario(UsuarioG usuario) {
        this.usuario = usuario;
    }

//    @Override
//    public int hashCode() {
//        int hash = 0;
//        hash += (idEmprestimo != null ? idEmprestimo.hashCode() : 0);
//        return hash;
//    }
//
//    @Override
//    public boolean equals(Object o) {
//        if (!(o instanceof EmprestimoG)) {
//            return false; //Se não for a instância desejada, retorna false;
//        } else {
//            EmprestimoG other = (EmprestimoG) o;
//            return !((this.idEmprestimo == null && other.idEmprestimo != null)
//                    || (this.idEmprestimo != null
//                    && !this.idEmprestimo.equals(other.idEmprestimo)));
//            /* 
//         * Se a sentença for verdadeira, retorna false. 
//         * Se for falsa, retorna true.        
//             */
//        }
//    }

}
