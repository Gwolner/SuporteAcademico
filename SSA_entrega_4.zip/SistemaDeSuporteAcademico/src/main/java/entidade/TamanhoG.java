package entidade;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;
import org.hibernate.validator.constraints.NotBlank;

@Entity
@Table(name="TB_TAMANHO")
@NamedQueries(
        {
            @NamedQuery(
                    name = TamanhoG.TAMANHO_POR_DESCRICAO,
                    query = "SELECT t FROM TamanhoG t WHERE t.descricaoTamanho = ?1"
            ),
            @NamedQuery(
                    name = TamanhoG.TAMANHOS,
                    query = "SELECT t FROM TamanhoG t ORDER BY t.descricaoTamanho"
            ),
             @NamedQuery(
                    name = TamanhoG.TAMANHO_POR_DESCRICAO_E_ID,
                    query = "SELECT t FROM TamanhoG t WHERE t.descricaoTamanho = ?1 AND t.id = ?2"
            ),
             @NamedQuery(
                    name = TamanhoG.TAMANHO_POR_ID,
                    query = "SELECT t FROM TamanhoG t WHERE t.id= ?1"
            ) 
        }
)
@Access(AccessType.FIELD)
public class TamanhoG extends Entidade implements Serializable {
    
    public static final String TAMANHOS = "Tamanhos";
    public static final String TAMANHO_POR_DESCRICAO = "TamanhoPorDescricao";        
    public static final String TAMANHO_POR_DESCRICAO_E_ID = "TamanhoPorDescricaoEId";
    public static final String TAMANHO_POR_ID = "TamanhoPorId";
    
    public TamanhoG() {
        this.fardamentos = new ArrayList<>();
    }
    
//    @Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
//    @Column(name="id_tamanho")
//    private Long idTamanho;
    
    @NotBlank(message="{Tamanho.descricaoTamanho.NotBlank}")
    @Column(name="descricao_tamanho")
    @Pattern(regexp="[A-Z]{0,2}", message="{Tamanho.descricaoTamanho}")
    private String descricaoTamanho;
    
    
    //Cardinalidade TamanhoG 1 : N FardamentoG
    @OneToMany (cascade = CascadeType.ALL, mappedBy = "tamanho", 
            fetch = FetchType.LAZY)
    protected List<FardamentoG> fardamentos;
    
    
//    public Long getIdTamanho() {
//        return this.idTamanho;
//    }
//
//    public void setIdTamanho(Long idTamanho) {
//        this.idTamanho = idTamanho;
//    }

    public String getDescricaoTamanho() {
        return this.descricaoTamanho;
    }

    public void setDescricaoTamanho(String descricaoTamanho) {
        this.descricaoTamanho = descricaoTamanho;
    }

    public List<FardamentoG> getFardamentos() {
        return this.fardamentos;
    }

    public boolean addFardamento(FardamentoG f) {
        if (!fardamentos.contains(f)) {
            f.setTamanho(this);
            return fardamentos.add(f);
        } else {
            return false;
        }   
    }
    
    public void addAllFardamentos(List<FardamentoG> fardamentos) {
        for (FardamentoG fardamento : fardamentos) {
            this.addFardamento(fardamento);
        }
    }
    
    public boolean removeFardamento(Object o) {
        if(!(o instanceof FardamentoG)){
            return false;
        }else{
            return fardamentos.remove(o);
        }    
    }
    
    
    
//    @Override
//    public int hashCode() {
//        int hash = 0;
//        hash += (idTamanho != null ? idTamanho.hashCode():0);
//        return hash;
//    }
//    
//    @Override
//    public boolean equals(Object o){
//        if (!(o instanceof TamanhoG)) {
//            return false; //Se não for a instância desejada, retorna false;
//        }else{ 
//            TamanhoG other = (TamanhoG) o;
//            return !((this.idTamanho == null && other.idTamanho != null)
//                    ||(this.idTamanho != null && 
//                    !this.idTamanho.equals(other.idTamanho))
//            );
//        /* 
//         * Se a sentença for verdadeira, retorna false. 
//         * Se for falsa, retorna true.        
//         */
//        }
//    }
}
