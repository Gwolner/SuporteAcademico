package beans;

import entidade.TamanhoG;
import excecao.ExcecaoNegocio;
import java.io.Serializable;
import java.util.List;
import javafx.scene.control.TableColumn.CellEditEvent;
import javax.inject.Named;
import javax.enterprise.context.RequestScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import servico.TamanhoServico;


@RequestScoped
@Named
public class TamanhoBean extends Bean<TamanhoG> implements Serializable {

    @Inject
    private TamanhoServico servicoTamanho;

    private TamanhoG tamanho = new TamanhoG();
    
    private List<TamanhoG> tamanhos;
    
    @Override
    protected void iniciarCampos() {
        setEntidade(servicoTamanho.criar());
    }

    @Override
    protected boolean salvar(TamanhoG entidade) throws ExcecaoNegocio {
        servicoTamanho.salvar(entidade);
        return true;
    }

    public TamanhoG getTamanho() {
        return tamanho;
    }

    public void setTamanho(TamanhoG tamanho) {
        this.tamanho = tamanho;
    }
    
    public List<TamanhoG> getTamanhos() {
        if (tamanhos == null) {
            tamanhos = servicoTamanho.getTamanhos();
        }

        return tamanhos;
    }
    
//    //Métodos de apoio ao teste de DELETE
//    
//    public TamanhoG getSelectedTamanho() {
//        return selectedTamanho;
//    }
// 
//    public void setSelectedTamanho(TamanhoG selectedTamanho) {
//        this.selectedTamanho = selectedTamanho;
//    }
//    
//    //DELETE funcionando apenas para linha selecionada!
//    public void deleteSelected() throws ExcecaoNegocio {
//        servicoTamanho.remover(selectedTamanho); //Remover do BD
//        tamanhos.remove(selectedTamanho); //Remover da List
//        selectedTamanho = null;
//    }    
    
    public void deleteTamanho(TamanhoG entidade) throws ExcecaoNegocio {
        servicoTamanho.remover(entidade); //Remover do BD
        tamanhos.remove(entidade); //Remover da List
//        selectedTamanho = null;
    }
    
    //UPDATE funcionando!
    public void atualizarTamanho() throws ExcecaoNegocio {
        servicoTamanho.atualizar(this.tamanho);
    }
}