package beans;

import entidade.AlunoG;
import entidade.FardamentoG;
import entidade.SituacaoG;
import entidade.TamanhoG;
import excecao.ExcecaoNegocio;
import java.io.Serializable;
import java.util.List;
import javafx.scene.control.TableColumn.CellEditEvent;
import javax.inject.Named;
import javax.enterprise.context.RequestScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import servico.AlunoServico;
import servico.FardamentoServico;
import servico.SituacaoServico;
import servico.TamanhoServico;


@RequestScoped
@Named
public class FardamentoBean extends Bean<FardamentoG> implements Serializable {

    @Inject
    private FardamentoServico servicoFardamento;
    
    @Inject
    private TamanhoServico servicoTamanho;
    
    @Inject
    private SituacaoServico servicoSituacao;

    @Inject
    private AlunoServico servicoAluno;
    
    private TamanhoG tamanhoSelected;
    
    private SituacaoG situacaoSelected;
    
    private FardamentoG fardamento = new FardamentoG();
    
    private List<FardamentoG> fardamentos;
    
    @Override
    protected void iniciarCampos() {
        setEntidade(servicoFardamento.criar());
    }

    @Override
    protected boolean salvar(FardamentoG entidade) throws ExcecaoNegocio {        
        this.servicoFardamento.salvar(entidade);
        return true;
    }
    
    public FardamentoG getFardamento() {
        return fardamento;
    }

    public void setFardamento(FardamentoG fardamento) {
        this.fardamento = fardamento;
    }
    
    public List<FardamentoG> getFardamentos() {
//        if (fardamentos == null) {
//            fardamentos = servicoFardamento.getFardamentos();
//        }
//        return fardamentos
        return servicoFardamento.getFardamentos();
    } 
    
    public List<TamanhoG> getTamanhos() {
        return servicoTamanho.getTamanhos();
    }
    
    public List<SituacaoG> getSituacoes() {
        return servicoSituacao.getSituacoes();
    }   
    
    public List<AlunoG> getAlunos() {
        return servicoAluno.getAlunos();
    } 
    
    public void deleteFardamento(FardamentoG entidade) throws ExcecaoNegocio {
        servicoFardamento.remover(entidade); //Remover do BD
        fardamentos.remove(entidade); //Remover da List
    }
    
    //UPDATE funcionando!
    public void atualizarFardamento() throws ExcecaoNegocio {
        servicoFardamento.atualizar(this.fardamento);
    }
}