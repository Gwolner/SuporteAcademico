package beans;

import entidade.VolumeG;
import excecao.ExcecaoNegocio;
import java.io.Serializable;
import java.util.List;
import javafx.scene.control.TableColumn.CellEditEvent;
import javax.inject.Named;
import javax.enterprise.context.RequestScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import servico.VolumeServico;


@RequestScoped
@Named
public class VolumeBean extends Bean<VolumeG> implements Serializable {

    @Inject
    private VolumeServico servicoVolume;

    private VolumeG volume = new VolumeG();
    
    private List<VolumeG> volumes;
    
    @Override
    protected void iniciarCampos() {
        setEntidade(servicoVolume.criar());
    }

    @Override
    protected boolean salvar(VolumeG entidade) throws ExcecaoNegocio {
        servicoVolume.salvar(entidade);
        return true;
    }

    public VolumeG getVolume() {
        return volume;
    }

    public void setVolume(VolumeG volume) {
        this.volume = volume;
    }
    
    public List<VolumeG> getVolumes() {
        if (volumes == null) {
            volumes = servicoVolume.getVolumes();
        }

        return volumes;
    }
    
//    //Métodos de apoio ao teste de DELETE
//    
//    public VolumeG getSelectedVolume() {
//        return selectedVolume;
//    }
// 
//    public void setSelectedVolume(VolumeG selectedVolume) {
//        this.selectedVolume = selectedVolume;
//    }
//    
//    //DELETE funcionando apenas para linha selecionada!
//    public void deleteSelected() throws ExcecaoNegocio {
//        servicoVolume.remover(selectedVolume); //Remover do BD
//        volumes.remove(selectedVolume); //Remover da List
//        selectedVolume = null;
//    }    
    
    public void deleteVolume(VolumeG entidade) throws ExcecaoNegocio {
        servicoVolume.remover(entidade); //Remover do BD
        volumes.remove(entidade); //Remover da List
//        selectedVolume = null;
    }
    
    //UPDATE funcionando!
    public void atualizarVolume() throws ExcecaoNegocio {
        servicoVolume.atualizar(this.volume);
    }
}