package servico;

import entidade.FardamentoG;
import excecao.ExcecaoNegocio;
import java.util.List;
import javax.annotation.security.PermitAll;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import static javax.ejb.TransactionAttributeType.REQUIRED;
import static javax.ejb.TransactionAttributeType.SUPPORTS;
import javax.ejb.TransactionManagement;
import static javax.ejb.TransactionManagementType.CONTAINER;
import javax.persistence.Query;
import javax.validation.executable.ExecutableType;
import javax.validation.executable.ValidateOnExecution;

@Stateless
//@LocalBean
//@DeclareRoles({ADMINISTRADOR, USUARIO})
@TransactionManagement(CONTAINER)
@TransactionAttribute(REQUIRED)
@ValidateOnExecution(type = ExecutableType.NON_GETTER_METHODS)
public class FardamentoServico extends Servico<FardamentoG> {

    //@RolesAllowed({ADMINISTRADOR})
    public void salvar(FardamentoG fardamento) throws ExcecaoNegocio {
//        checarExistencia(FardamentoG.VOLUME_POR_DESCRICAO, fardamento.getDescricaoFardamento());
        entityManager.persist(fardamento);

//        entityManager.createNativeQuery("insert into tb_fardamento (quantidade_entregue, id_situacao, id_tamanho, id_aluno) values("
//                + fardamento.getQuantidadeEntregue()
//                + ", "
//                + fardamento.getSituacao().getId()
//                + ", "
//                + fardamento.getTamanho().getId()
//                + ", "
//                + fardamento.getAluno().getId()
//                + ")").executeUpdate();

    }

    //@RolesAllowed({ADMINISTRADOR})
    public void atualizar(FardamentoG fardamento) throws ExcecaoNegocio {
//        checarNaoExistencia(FardamentoG.FARDAMENTO_POR_ID, new Object[]{fardamento.getId()});
//        entityManager.merge(fardamento);
//        entityManager.flush();
        Query update = entityManager.createQuery("UPDATE FardamentoG AS f SET f.quantidadeEntregue = ?1 WHERE f.id = ?2");
        update.setParameter(1, fardamento.getQuantidadeEntregue());
        update.setParameter(2, fardamento.getId());
        update.executeUpdate();
    }

    //@RolesAllowed({ADMINISTRADOR})
    public void remover(FardamentoG fardamento) throws ExcecaoNegocio {
        fardamento = entityManager.merge(fardamento);
        if (fardamento.isInativo()) {
            entityManager.remove(fardamento);
        } else {
            throw new ExcecaoNegocio(ExcecaoNegocio.REMOVER_AUTOR);
        }
    }

//    //@RolesAllowed({ADMINISTRADOR})
//    public void remover(String cpf) throws ExcecaoNegocio {
//        FardamentoG fardamento = getFardamento(cpf);
//        remover(fardamento);
//    }
    @TransactionAttribute(SUPPORTS)
    @PermitAll
    public List<FardamentoG> getFardamentos() {
        return getEntidades(FardamentoG.FARDAMENTOS);
    }

    @TransactionAttribute(SUPPORTS)
    @PermitAll
    public List<FardamentoG> getFardamentosPorId(Long id) {
        return getEntidades(FardamentoG.FARDAMENTO_POR_ID, new Object[]{id});
    }

//    @TransactionAttribute(SUPPORTS)
//    @PermitAll
//    public FardamentoG getFardamento(String desc) {
//        return super.getEntidade(FardamentoG.VOLUME_POR_DESCRICAO, new Object[]{desc});
//    }
    @TransactionAttribute(SUPPORTS)
    @PermitAll
    public FardamentoG criar() {
        return new FardamentoG();
    }
}
