package servico;

import entidade.ProfessorG;
import excecao.ExcecaoNegocio;
import java.util.List;
import javax.annotation.security.PermitAll;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import static javax.ejb.TransactionAttributeType.REQUIRED;
import static javax.ejb.TransactionAttributeType.SUPPORTS;
import javax.ejb.TransactionManagement;
import static javax.ejb.TransactionManagementType.CONTAINER;
import javax.validation.executable.ExecutableType;
import javax.validation.executable.ValidateOnExecution;


@Stateless
@LocalBean
//@DeclareRoles({ADMINISTRADOR, USUARIO})
@TransactionManagement(CONTAINER)
@TransactionAttribute(REQUIRED)
@ValidateOnExecution(type = ExecutableType.NON_GETTER_METHODS)
public class ProfessorServico extends Servico<ProfessorG> {

    //@RolesAllowed({ADMINISTRADOR})
    public void salvar(ProfessorG professor) throws ExcecaoNegocio {
        checarExistencia(ProfessorG.PROFESSOR_POR_SIAPE, professor.getSiape());
        entityManager.persist(professor);
    }

    //@RolesAllowed({ADMINISTRADOR})
    public void atualizar(ProfessorG professor) throws ExcecaoNegocio {
        checarNaoExistencia(ProfessorG.PROFESSOR_POR_ID, new Object[]{professor.getId()});        
        entityManager.merge(professor);
        entityManager.flush();
    }

    //@RolesAllowed({ADMINISTRADOR})
    public void remover(ProfessorG professor) throws ExcecaoNegocio {
        professor = entityManager.merge(professor);
        if (professor.isInativo()) {
            entityManager.remove(professor);
        } else {
            throw new ExcecaoNegocio(ExcecaoNegocio.REMOVER_AUTOR);
        }
    }

    //@RolesAllowed({ADMINISTRADOR})
    public void remover(String cpf) throws ExcecaoNegocio {
        ProfessorG professor = getProfessor(cpf);
        remover(professor);
    }

    @TransactionAttribute(SUPPORTS)
    @PermitAll
    public List<ProfessorG> getProfessores() {
        return getEntidades(ProfessorG.PROFESSORES);
    }

    @TransactionAttribute(SUPPORTS)
    @PermitAll
    public ProfessorG getProfessor(String siape) {
        return super.getEntidade(ProfessorG.PROFESSOR_POR_SIAPE, new Object[]{siape});
    }

    @TransactionAttribute(SUPPORTS)
    @PermitAll
    public ProfessorG criar() {
        return new ProfessorG();
    }
}
