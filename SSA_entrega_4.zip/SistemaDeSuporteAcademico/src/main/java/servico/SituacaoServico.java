package servico;

import entidade.SituacaoG;
import excecao.ExcecaoNegocio;
import java.util.List;
import javax.annotation.security.PermitAll;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import static javax.ejb.TransactionAttributeType.REQUIRED;
import static javax.ejb.TransactionAttributeType.SUPPORTS;
import javax.ejb.TransactionManagement;
import static javax.ejb.TransactionManagementType.CONTAINER;
import javax.validation.executable.ExecutableType;
import javax.validation.executable.ValidateOnExecution;


@Stateless
@LocalBean
//@DeclareRoles({ADMINISTRADOR, USUARIO})
@TransactionManagement(CONTAINER)
@TransactionAttribute(REQUIRED)
@ValidateOnExecution(type = ExecutableType.NON_GETTER_METHODS)
public class SituacaoServico extends Servico<SituacaoG> {

    //@RolesAllowed({ADMINISTRADOR})
    public void salvar(SituacaoG situacao) throws ExcecaoNegocio {
        checarExistencia(SituacaoG.SITUACAO_POR_DESCRICAO, situacao.getDescricaoSituacao());
        entityManager.persist(situacao);
    }

    //@RolesAllowed({ADMINISTRADOR})
    public void atualizar(SituacaoG situacao) throws ExcecaoNegocio {
        checarNaoExistencia(SituacaoG.SITUACAO_POR_ID, new Object[]{situacao.getId()});        
        entityManager.merge(situacao);
        entityManager.flush();
    }

    //@RolesAllowed({ADMINISTRADOR})
    public void remover(SituacaoG situacao) throws ExcecaoNegocio {
        situacao = entityManager.merge(situacao);
        if (situacao.isInativo()) {
            entityManager.remove(situacao);
        } else {
            throw new ExcecaoNegocio(ExcecaoNegocio.REMOVER_AUTOR);
        }
    }

    //@RolesAllowed({ADMINISTRADOR})
    public void remover(String cpf) throws ExcecaoNegocio {
        SituacaoG situacao = getSituacao(cpf);
        remover(situacao);
    }

    @TransactionAttribute(SUPPORTS)
    @PermitAll
    public List<SituacaoG> getSituacoes() {
        return getEntidades(SituacaoG.SITUACOES);
    }

    @TransactionAttribute(SUPPORTS)
    @PermitAll
    public SituacaoG getSituacao(String desc) {
        return super.getEntidade(SituacaoG.SITUACAO_POR_DESCRICAO, new Object[]{desc});
    }

    @TransactionAttribute(SUPPORTS)
    @PermitAll
    public SituacaoG criar() {
        return new SituacaoG();
    }
}
