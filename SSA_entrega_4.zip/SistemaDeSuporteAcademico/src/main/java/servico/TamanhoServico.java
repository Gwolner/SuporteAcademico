package servico;

import entidade.TamanhoG;
import excecao.ExcecaoNegocio;
import java.util.List;
import javax.annotation.security.PermitAll;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import static javax.ejb.TransactionAttributeType.REQUIRED;
import static javax.ejb.TransactionAttributeType.SUPPORTS;
import javax.ejb.TransactionManagement;
import static javax.ejb.TransactionManagementType.CONTAINER;
import javax.validation.executable.ExecutableType;
import javax.validation.executable.ValidateOnExecution;


@Stateless
@LocalBean
//@DeclareRoles({ADMINISTRADOR, USUARIO})
@TransactionManagement(CONTAINER)
@TransactionAttribute(REQUIRED)
@ValidateOnExecution(type = ExecutableType.NON_GETTER_METHODS)
public class TamanhoServico extends Servico<TamanhoG> {

    //@RolesAllowed({ADMINISTRADOR})
    public void salvar(TamanhoG tamanho) throws ExcecaoNegocio {
        checarExistencia(TamanhoG.TAMANHO_POR_DESCRICAO, tamanho.getDescricaoTamanho());
        entityManager.persist(tamanho);
    }

    //@RolesAllowed({ADMINISTRADOR})
    public void atualizar(TamanhoG tamanho) throws ExcecaoNegocio {
        checarNaoExistencia(TamanhoG.TAMANHO_POR_ID, new Object[]{tamanho.getId()});        
        entityManager.merge(tamanho);
        entityManager.flush();
    }

    //@RolesAllowed({ADMINISTRADOR})
    public void remover(TamanhoG tamanho) throws ExcecaoNegocio {
        tamanho = entityManager.merge(tamanho);
        if (tamanho.isInativo()) {
            entityManager.remove(tamanho);
        } else {
            throw new ExcecaoNegocio(ExcecaoNegocio.REMOVER_AUTOR);
        }
    }

    //@RolesAllowed({ADMINISTRADOR})
    public void remover(String cpf) throws ExcecaoNegocio {
        TamanhoG tamanho = getTamanho(cpf);
        remover(tamanho);
    }

    @TransactionAttribute(SUPPORTS)
    @PermitAll
    public List<TamanhoG> getTamanhos() {
        return getEntidades(TamanhoG.TAMANHOS);
    }

    @TransactionAttribute(SUPPORTS)
    @PermitAll
    public TamanhoG getTamanho(String desc) {
        return super.getEntidade(TamanhoG.TAMANHO_POR_DESCRICAO, new Object[]{desc});
    }

    @TransactionAttribute(SUPPORTS)
    @PermitAll
    public TamanhoG criar() {
        return new TamanhoG();
    }
}
