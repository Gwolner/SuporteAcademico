package servico;

import entidade.LivroG;
import excecao.ExcecaoNegocio;
import java.util.List;
import javax.annotation.security.PermitAll;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import static javax.ejb.TransactionAttributeType.REQUIRED;
import static javax.ejb.TransactionAttributeType.SUPPORTS;
import javax.ejb.TransactionManagement;
import static javax.ejb.TransactionManagementType.CONTAINER;
import javax.persistence.Query;
import javax.validation.executable.ExecutableType;
import javax.validation.executable.ValidateOnExecution;

@Stateless
@LocalBean
//@DeclareRoles({ADMINISTRADOR, USUARIO})
@TransactionManagement(CONTAINER)
@TransactionAttribute(REQUIRED)
@ValidateOnExecution(type = ExecutableType.NON_GETTER_METHODS)
public class LivroServico extends Servico<LivroG> {

    //@RolesAllowed({ADMINISTRADOR})
    public void salvar(LivroG livro) throws ExcecaoNegocio {
        checarExistencia(LivroG.LIVRO_POR_ISBN, livro.getIsbn());

//        System.out.println("ID VOLUME >>>>>>>>>>>>> "+livro.getVolume().getId());        
        entityManager.persist(livro);
//        entityManager.createNativeQuery("insert into tb_livro (autor, isbn, materia, quantidade, titulo, id_volume) values('"
//                + livro.getAutor()
//                + "', "
//                + livro.getIsbn()
//                + ", '"
//                + livro.getMateria()
//                + "', "
//                + livro.getQuantidade()
//                + ", '"
//                + livro.getTitulo()
//                + "', "
//                + livro.getVolume().getId() + ")").executeUpdate();
    }

    //@RolesAllowed({ADMINISTRADOR})
    public void atualizar(LivroG livro) throws ExcecaoNegocio {
//        checarNaoExistencia(LivroG.VOLUME_POR_ID, new Object[]{livro.getIdLivro()});        
//        entityManager.merge(livro);

//        entityManager.createNativeQuery("update tb_livro set autor= '"+livro.getAutor()+"' , isbn="+livro.getIsbn()+", materia= '"+livro.getMateria()+"', quantidade="+livro.getQuantidade()+", titulo= '"+livro.getTitulo()+"' where id="+livro.getId()).executeUpdate();
//        entityManager.createNativeQuery("update tb_livro set id_volume = "+livro.getVolume().getId()+" where id="+livro.getId()).executeUpdate();
//          System.out.println("ID VOLUME >>>>>>>>>>>>> "+livro.getVolume().getId());  
//          Query update = entityManager.createQuery("UPDATE LivroG AS l SET l.autor = ?1, l.isbn = ?2, l.materia= ?3, l.quantidade = ?4, l.titulo = ?5 WHERE l.id = ?6");
          Query update = entityManager.createQuery("UPDATE LivroG AS l SET l.autor = ?1, l.isbn = ?2, l.materia= ?3, l.quantidade = ?4, l.titulo = ?5 WHERE l.id = ?6");
          update.setParameter(1, livro.getAutor());
          update.setParameter(2, livro.getIsbn());
          update.setParameter(3, livro.getMateria());
          update.setParameter(4, livro.getQuantidade());
          update.setParameter(5, livro.getTitulo());
          update.setParameter(6, livro.getId());
          update.executeUpdate();
        
//        entityManager.flush();
    }

    //@RolesAllowed({ADMINISTRADOR})
    public void remover(LivroG livro) throws ExcecaoNegocio {
        livro = entityManager.merge(livro);
        if (livro.isInativo()) {
            entityManager.remove(livro);
        } else {
            throw new ExcecaoNegocio(ExcecaoNegocio.REMOVER_AUTOR);
        }
    }

    //@RolesAllowed({ADMINISTRADOR})
    public void remover(String cpf) throws ExcecaoNegocio {
        LivroG livro = getLivro(cpf);
        remover(livro);
    }

    @TransactionAttribute(SUPPORTS)
    @PermitAll
    public List<LivroG> getLivros() {
        return getEntidades(LivroG.LIVROS);
    }

    @TransactionAttribute(SUPPORTS)
    @PermitAll
    public LivroG getLivro(String isbn) {
        return super.getEntidade(LivroG.LIVRO_POR_ISBN, new Object[]{isbn});
    }

    @TransactionAttribute(SUPPORTS)
    @PermitAll
    public LivroG criar() {
        return new LivroG();
    }
}
