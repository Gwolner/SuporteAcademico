package beans;

import entidade.LivroG;
import entidade.VolumeG;
import excecao.ExcecaoNegocio;
import java.io.Serializable;
import java.util.List;
import javafx.scene.control.TableColumn.CellEditEvent;
import javax.inject.Named;
import javax.enterprise.context.RequestScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import servico.LivroServico;
import servico.VolumeServico;


@RequestScoped
@Named
public class LivroBean extends Bean<LivroG> implements Serializable {

    @Inject
    private LivroServico servicoLivro;
    
    @Inject
    private VolumeServico servicoVolume;

    private VolumeG volumeSelected;
    
    private LivroG livro = new LivroG();
    
    private List<LivroG> livros;
    
    @Override
    protected void iniciarCampos() {
        setEntidade(servicoLivro.criar());
    }

    @Override
    protected boolean salvar(LivroG entidade) throws ExcecaoNegocio {
        this.servicoLivro.salvar(entidade);
        return true;
    }
    
    public LivroG getLivro() {
        return livro;
    }

    public void setLivro(LivroG livro) {
        this.livro = livro;
    }
    
    public List<LivroG> getLivros() {
        if (livros == null) {
            livros = servicoLivro.getLivros();
        }

        return livros;
    } 
    
    public List<VolumeG> getVolumes() {
        return servicoVolume.getVolumes();
    }
    
    public void deleteLivro(LivroG entidade) throws ExcecaoNegocio {
        servicoLivro.remover(entidade); //Remover do BD
        livros.remove(entidade); //Remover da List
    }
    
    //UPDATE funcionando!
    public void atualizarLivro() throws ExcecaoNegocio {
        servicoLivro.atualizar(this.livro);
    }
}