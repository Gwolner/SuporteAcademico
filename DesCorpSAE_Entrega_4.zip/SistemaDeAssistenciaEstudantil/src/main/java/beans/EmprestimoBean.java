package beans;

import entidade.AlunoG;
import entidade.EmprestimoG;
import entidade.LivroG;
import entidade.ProfessorG;
import entidade.SituacaoG;
import entidade.TamanhoG;
import excecao.ExcecaoNegocio;
import java.io.Serializable;
import java.util.List;
import javafx.scene.control.TableColumn.CellEditEvent;
import javax.inject.Named;
import javax.enterprise.context.RequestScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import servico.AlunoServico;
import servico.EmprestimoServico;
import servico.LivroServico;
import servico.ProfessorServico;
import servico.SituacaoServico;
import servico.TamanhoServico;


@RequestScoped
@Named
public class EmprestimoBean extends Bean<EmprestimoG> implements Serializable {

    @Inject
    private EmprestimoServico servicoEmprestimo;

    @Inject
    private AlunoServico servicoAluno;
    
    @Inject
    private ProfessorServico servicoProfessor;
    
    @Inject
    private LivroServico servicoLivro;
    
        
    private EmprestimoG emprestimo = new EmprestimoG();
    
    private List<EmprestimoG> emprestimos;
    
    @Override
    protected void iniciarCampos() {
        setEntidade(servicoEmprestimo.criar());
    }

    @Override
    protected boolean salvar(EmprestimoG entidade) throws ExcecaoNegocio {        
        this.servicoEmprestimo.salvar(entidade);
        return true;
    }
    
    public EmprestimoG getEmprestimo() {
        return emprestimo;
    }

    public void setEmprestimo(EmprestimoG emprestimo) {
        this.emprestimo = emprestimo;
    }
    
    public List<EmprestimoG> getEmprestimos() {
//        if (emprestimos == null) {
//            emprestimos = servicoEmprestimo.getEmprestimos();
//        }
//        return emprestimos
        return servicoEmprestimo.getEmprestimos();
    }   
    
    public List<AlunoG> getAlunos() {
        return servicoAluno.getAlunos();
    }
    
    public List<ProfessorG> getProfessores() {
        return servicoProfessor.getProfessores();
    }
    
    public List<LivroG> getLivros() {
        return servicoLivro.getLivros();
    }
    
    public void deleteEmprestimo(EmprestimoG entidade) throws ExcecaoNegocio {
        servicoEmprestimo.remover(entidade); //Remover do BD
        emprestimos.remove(entidade); //Remover da List
    }
    
    //UPDATE funcionando!
    public void atualizarEmprestimo() throws ExcecaoNegocio {
        servicoEmprestimo.atualizar(this.emprestimo);
    }
    
    public void atualizarEmprestimo(EmprestimoG emprestimo) throws ExcecaoNegocio {
        servicoEmprestimo.atualizar(emprestimo);
    }
    
}