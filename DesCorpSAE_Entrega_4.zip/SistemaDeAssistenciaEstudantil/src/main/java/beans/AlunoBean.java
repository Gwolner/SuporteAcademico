package beans;

import entidade.AlunoG;
import entidade.EmprestimoG;
import entidade.FardamentoG;
import entidade.LivroG;
import excecao.ExcecaoNegocio;
import java.io.Serializable;
import java.util.List;
import javafx.scene.control.TableColumn.CellEditEvent;
import javax.inject.Named;
import javax.enterprise.context.RequestScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import servico.AlunoServico;
import servico.EmprestimoServico;
import servico.FardamentoServico;
import servico.LivroServico;


@RequestScoped
@Named
public class AlunoBean extends Bean<AlunoG> implements Serializable {

    @Inject
    private AlunoServico servicoAluno;
    
    @Inject
    private FardamentoServico servicoFardamento;
    
    @Inject
    private EmprestimoServico servicoEmprestimo;

    private FardamentoG fardamentoSelected;
    
    private AlunoG alunos = new AlunoG();
    
    private List<AlunoG> alunoss;
    
    @Override
    protected void iniciarCampos() {
        setEntidade(servicoAluno.criar());
    }

    @Override
    protected boolean salvar(AlunoG entidade) throws ExcecaoNegocio {
        this.servicoAluno.salvar(entidade);
        return true;
    }
    
    public AlunoG getAluno() {
        return alunos;
    }

    public void setAluno(AlunoG alunos) {
        this.alunos = alunos;
    }
    
    public List<AlunoG> getAlunos() {
        if (alunoss == null) {
            alunoss = servicoAluno.getAlunos();
        }

        return alunoss;
    } 
    
    public List<FardamentoG> getFardamentos() {
        return servicoFardamento.getFardamentos();
    }
    
    public List<FardamentoG> getFardamentosPorId(Long id) {
        return servicoFardamento.getFardamentosPorId(id);
    }
    
    public List<EmprestimoG> getEmprestimosPorId(Long id) {
        return servicoEmprestimo.getEmprestimosPorId(id);
    }
    
    public void deleteAluno(AlunoG entidade) throws ExcecaoNegocio {
        servicoAluno.remover(entidade); //Remover do BD
        alunoss.remove(entidade); //Remover da List
    }
    
    //UPDATE funcionando!
    public void atualizarAluno() throws ExcecaoNegocio {
        servicoAluno.atualizar(this.alunos);
    }
    
    public AlunoG buscarPorMatricula(String matricula){
        return servicoAluno.getAluno(matricula);
    }
}