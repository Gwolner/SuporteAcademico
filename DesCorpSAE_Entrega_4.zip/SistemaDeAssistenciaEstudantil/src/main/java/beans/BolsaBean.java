package beans;

import entidade.AlunoG;
import entidade.BolsaG;
import excecao.ExcecaoNegocio;
import java.io.Serializable;
import java.util.List;
import javafx.scene.control.TableColumn.CellEditEvent;
import javax.inject.Named;
import javax.enterprise.context.RequestScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import servico.AlunoServico;
import servico.BolsaServico;

@RequestScoped
@Named
public class BolsaBean extends Bean<BolsaG> implements Serializable {

    @Inject
    private BolsaServico servicoBolsa;

    @Inject
    private AlunoServico servicoAluno;

    private BolsaG bolsa = new BolsaG();

    private List<BolsaG> bolsas;

    @Override
    protected void iniciarCampos() {
        setEntidade(servicoBolsa.criar());
    }

    @Override
    protected boolean salvar(BolsaG entidade) throws ExcecaoNegocio {
        servicoBolsa.salvar(entidade);
        return true;
    }

    public BolsaG getBolsa() {
        return bolsa;
    }

    public void setBolsa(BolsaG bolsa) {
        this.bolsa = bolsa;
    }

    public List<BolsaG> getBolsas() {
        if (bolsas == null) {
            bolsas = servicoBolsa.getBolsas();
        }

        return bolsas;
    }

    public List<AlunoG> getAlunos() {
        return servicoAluno.getAlunos();
    }
//    //Métodos de apoio ao teste de DELETE
//    
//    public BolsaG getSelectedBolsa() {
//        return selectedBolsa;
//    }
// 
//    public void setSelectedBolsa(BolsaG selectedBolsa) {
//        this.selectedBolsa = selectedBolsa;
//    }
//    
//    //DELETE funcionando apenas para linha selecionada!
//    public void deleteSelected() throws ExcecaoNegocio {
//        servicoBolsa.remover(selectedBolsa); //Remover do BD
//        bolsas.remove(selectedBolsa); //Remover da List
//        selectedBolsa = null;
//    }  
    
    public void deleteBolsa(BolsaG entidade) throws ExcecaoNegocio {
        servicoBolsa.remover(entidade); //Remover do BD
        bolsas.remove(entidade); //Remover da List
    }

    //UPDATE funcionando!
    public void atualizarBolsa() throws ExcecaoNegocio {
        servicoBolsa.atualizar(this.bolsa);
    }
}
