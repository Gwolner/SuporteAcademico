package beans;

import entidade.SituacaoG;
import excecao.ExcecaoNegocio;
import java.io.Serializable;
import java.util.List;
import javafx.scene.control.TableColumn.CellEditEvent;
import javax.inject.Named;
import javax.enterprise.context.RequestScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import servico.SituacaoServico;


@RequestScoped
@Named
public class SituacaoBean extends Bean<SituacaoG> implements Serializable {

    @Inject
    private SituacaoServico servicoSituacao;

    private SituacaoG situacao = new SituacaoG();
    
    private List<SituacaoG> situacoes;
    
    @Override
    protected void iniciarCampos() {
        setEntidade(servicoSituacao.criar());
    }

    @Override
    protected boolean salvar(SituacaoG entidade) throws ExcecaoNegocio {
        servicoSituacao.salvar(entidade);
        return true;
    }

    public SituacaoG getSituacao() {
        return situacao;
    }

    public void setSituacao(SituacaoG situacao) {
        this.situacao = situacao;
    }
    
    public List<SituacaoG> getSituacoes() {
        if (situacoes == null) {
            situacoes = servicoSituacao.getSituacoes();
        }

        return situacoes;
    }
    
//    //Métodos de apoio ao teste de DELETE
//    
//    public SituacaoG getSelectedSituacao() {
//        return selectedSituacao;
//    }
// 
//    public void setSelectedSituacao(SituacaoG selectedSituacao) {
//        this.selectedSituacao = selectedSituacao;
//    }
//    
//    //DELETE funcionando apenas para linha selecionada!
//    public void deleteSelected() throws ExcecaoNegocio {
//        servicoSituacao.remover(selectedSituacao); //Remover do BD
//        situacoes.remove(selectedSituacao); //Remover da List
//        selectedSituacao = null;
//    }    
    
    public void deleteSituacao(SituacaoG entidade) throws ExcecaoNegocio {
        servicoSituacao.remover(entidade); //Remover do BD
        situacoes.remove(entidade); //Remover da List
//        selectedSituacao = null;
    }
    
    //UPDATE funcionando!
    public void atualizarSituacao() throws ExcecaoNegocio {
        servicoSituacao.atualizar(this.situacao);
    }
}