package beans;

import entidade.ProfessorG;
import entidade.EmprestimoG;
import entidade.FardamentoG;
import entidade.LivroG;
import excecao.ExcecaoNegocio;
import java.io.Serializable;
import java.util.List;
import javafx.scene.control.TableColumn.CellEditEvent;
import javax.inject.Named;
import javax.enterprise.context.RequestScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import servico.ProfessorServico;
import servico.EmprestimoServico;
import servico.FardamentoServico;
import servico.LivroServico;


@RequestScoped
@Named
public class ProfessorBean extends Bean<ProfessorG> implements Serializable {

    @Inject
    private ProfessorServico servicoProfessor;
    
    @Inject
    private EmprestimoServico servicoEmprestimo;
    
    private ProfessorG professor = new ProfessorG();
    
    private List<ProfessorG> professores;
    
    @Override
    protected void iniciarCampos() {
        setEntidade(servicoProfessor.criar());
    }

    @Override
    protected boolean salvar(ProfessorG entidade) throws ExcecaoNegocio {
        this.servicoProfessor.salvar(entidade);
        return true;
    }
    
    public ProfessorG getProfessor() {
        return professor;
    }

    public void setProfessor(ProfessorG professor) {
        this.professor = professor;
    }
    
    public List<ProfessorG> getProfessores() {
        if (professores == null) {
            professores = servicoProfessor.getProfessores();
        }

        return professores;
    }
    
    public List<EmprestimoG> getEmprestimosPorId(Long id) {
        return servicoEmprestimo.getEmprestimosPorId(id);
    }
    
    public void deleteProfessor(ProfessorG entidade) throws ExcecaoNegocio {
        servicoProfessor.remover(entidade); //Remover do BD
        professores.remove(entidade); //Remover da List
    }
    
    //UPDATE funcionando!
    public void atualizarProfessor() throws ExcecaoNegocio {
        servicoProfessor.atualizar(this.professor);
    }
    
    public ProfessorG buscarPorMatricula(String matricula){
        return servicoProfessor.getProfessor(matricula);
    }
}