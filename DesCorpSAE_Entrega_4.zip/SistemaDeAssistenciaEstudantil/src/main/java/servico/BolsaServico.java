package servico;

import entidade.BolsaG;
import excecao.ExcecaoNegocio;
import java.util.List;
import javax.annotation.security.PermitAll;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import static javax.ejb.TransactionAttributeType.REQUIRED;
import static javax.ejb.TransactionAttributeType.SUPPORTS;
import javax.ejb.TransactionManagement;
import static javax.ejb.TransactionManagementType.CONTAINER;
import javax.validation.executable.ExecutableType;
import javax.validation.executable.ValidateOnExecution;

@Stateless
@LocalBean
//@DeclareRoles({ADMINISTRADOR, USUARIO})
@TransactionManagement(CONTAINER)
@TransactionAttribute(REQUIRED)
@ValidateOnExecution(type = ExecutableType.NON_GETTER_METHODS)
public class BolsaServico extends Servico<BolsaG> {

    //@RolesAllowed({ADMINISTRADOR})
    public void salvar(BolsaG bolsa) throws ExcecaoNegocio {
        checarExistencia(BolsaG.BOLSA_POR_NOME, bolsa.getNomeBolsa());
        entityManager.persist(bolsa); 
    }

    //@RolesAllowed({ADMINISTRADOR})
    public void atualizar(BolsaG bolsa) throws ExcecaoNegocio {
        checarNaoExistencia(BolsaG.BOLSA_POR_ID, new Object[]{bolsa.getId()});
        entityManager.merge(bolsa);
        entityManager.flush();
    }

    //@RolesAllowed({ADMINISTRADOR})
    public void remover(BolsaG bolsa) throws ExcecaoNegocio {
        bolsa = entityManager.merge(bolsa);
        if (bolsa.isInativo()) {
            entityManager.remove(bolsa);
        } else {
            throw new ExcecaoNegocio(ExcecaoNegocio.REMOVER_AUTOR);
        }
    }

    //@RolesAllowed({ADMINISTRADOR})
    public void remover(String cpf) throws ExcecaoNegocio {
        BolsaG bolsa = getBolsa(cpf);
        remover(bolsa);
    }

    @TransactionAttribute(SUPPORTS)
    @PermitAll
    public List<BolsaG> getBolsas() {
        return getEntidades(BolsaG.BOLSAS);
    }

    @TransactionAttribute(SUPPORTS)
    @PermitAll
    public BolsaG getBolsa(String nome) {
        return super.getEntidade(BolsaG.BOLSA_POR_NOME, new Object[]{nome});
    }

    @TransactionAttribute(SUPPORTS)
    @PermitAll
    public BolsaG criar() {
        return new BolsaG();
    }
}
