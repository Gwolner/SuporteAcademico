package servico;

import entidade.VolumeG;
import excecao.ExcecaoNegocio;
import java.util.List;
import javax.annotation.security.PermitAll;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import static javax.ejb.TransactionAttributeType.REQUIRED;
import static javax.ejb.TransactionAttributeType.SUPPORTS;
import javax.ejb.TransactionManagement;
import static javax.ejb.TransactionManagementType.CONTAINER;
import javax.validation.executable.ExecutableType;
import javax.validation.executable.ValidateOnExecution;


@Stateless
@LocalBean
//@DeclareRoles({ADMINISTRADOR, USUARIO})
@TransactionManagement(CONTAINER)
@TransactionAttribute(REQUIRED)
@ValidateOnExecution(type = ExecutableType.NON_GETTER_METHODS)
public class VolumeServico extends Servico<VolumeG> {

    //@RolesAllowed({ADMINISTRADOR})
    public void salvar(VolumeG volume) throws ExcecaoNegocio {
        checarExistencia(VolumeG.VOLUME_POR_DESCRICAO, volume.getDescricaoVolume());
        entityManager.persist(volume);
    }

    //@RolesAllowed({ADMINISTRADOR})
    public void atualizar(VolumeG volume) throws ExcecaoNegocio {
        checarNaoExistencia(VolumeG.VOLUME_POR_ID, new Object[]{volume.getId()});        
        entityManager.merge(volume);
        entityManager.flush();
    }

    //@RolesAllowed({ADMINISTRADOR})
    public void remover(VolumeG volume) throws ExcecaoNegocio {
        volume = entityManager.merge(volume);
        if (volume.isInativo()) {
            entityManager.remove(volume);
        } else {
            throw new ExcecaoNegocio(ExcecaoNegocio.REMOVER_AUTOR);
        }
    }

    //@RolesAllowed({ADMINISTRADOR})
    public void remover(String cpf) throws ExcecaoNegocio {
        VolumeG volume = getVolume(cpf);
        remover(volume);
    }

    @TransactionAttribute(SUPPORTS)
    @PermitAll
    public List<VolumeG> getVolumes() {
        return getEntidades(VolumeG.VOLUMES);
    }

    @TransactionAttribute(SUPPORTS)
    @PermitAll
    public VolumeG getVolume(String desc) {
        return super.getEntidade(VolumeG.VOLUME_POR_DESCRICAO, new Object[]{desc});
    }

    @TransactionAttribute(SUPPORTS)
    @PermitAll
    public VolumeG criar() {
        return new VolumeG();
    }
}
