package servico;

import entidade.EmprestimoG;
import entidade.FardamentoG;
import excecao.ExcecaoNegocio;
import java.util.List;
import javax.annotation.security.PermitAll;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import static javax.ejb.TransactionAttributeType.REQUIRED;
import static javax.ejb.TransactionAttributeType.SUPPORTS;
import javax.ejb.TransactionManagement;
import static javax.ejb.TransactionManagementType.CONTAINER;
import javax.persistence.Query;
import javax.validation.executable.ExecutableType;
import javax.validation.executable.ValidateOnExecution;

@Stateless
@LocalBean
//@DeclareRoles({ADMINISTRADOR, USUARIO})
@TransactionManagement(CONTAINER)
@TransactionAttribute(REQUIRED)
@ValidateOnExecution(type = ExecutableType.NON_GETTER_METHODS)
public class EmprestimoServico extends Servico<EmprestimoG> {

    //@RolesAllowed({ADMINISTRADOR})
    public void salvar(EmprestimoG emprestimo) throws ExcecaoNegocio {
//        checarExistencia(EmprestimoG.EMPRESTIMO_POR_STATUS, emprestimo.getStatus());
        entityManager.persist(emprestimo);

//        entityManager.createNativeQuery("insert into tb_emprestimo (data_entrega, data_devolucao, status, id_usuario, id_livro) values('"
//                + emprestimo.getDataEntrega()
//                + "', '"
//                + emprestimo.getDataDevolucao()
//                + "', '"
//                + emprestimo.getStatus()
//                + "', "
//                + emprestimo.getUsuario().getId()
//                + ", "
//                + emprestimo.getLivro().getId()
//                + ")").executeUpdate();
    }

    //@RolesAllowed({ADMINISTRADOR})
    public void atualizar(EmprestimoG emprestimo) throws ExcecaoNegocio {
//        checarNaoExistencia(EmprestimoG.EMPRESTIMO_POR_ID, new Object[]{emprestimo.getId()});
//        entityManager.merge(emprestimo);
//        entityManager.flush();

        Query update = entityManager.createQuery("UPDATE EmprestimoG AS e SET e.dataEntrega = ?1, e.dataDevolucao = ?2, e.status = ?3 WHERE e.id = ?4");
        update.setParameter(1, emprestimo.getDataEntrega());
        update.setParameter(2, emprestimo.getDataDevolucao());
        update.setParameter(3, emprestimo.getStatus());
        update.setParameter(4, emprestimo.getId());
        update.executeUpdate();

    }

    //@RolesAllowed({ADMINISTRADOR})
    public void remover(EmprestimoG emprestimo) throws ExcecaoNegocio {
        emprestimo = entityManager.merge(emprestimo);
        if (emprestimo.isInativo()) {
            entityManager.remove(emprestimo);
        } else {
            throw new ExcecaoNegocio(ExcecaoNegocio.REMOVER_AUTOR);
        }
    }

    //@RolesAllowed({ADMINISTRADOR})
    public void remover(String cpf) throws ExcecaoNegocio {
        EmprestimoG emprestimo = getEmprestimo(cpf);
        remover(emprestimo);
    }

    @TransactionAttribute(SUPPORTS)
    @PermitAll
    public List<EmprestimoG> getEmprestimos() {
        return getEntidades(EmprestimoG.EMPRESTIMOS);
    }

    @TransactionAttribute(SUPPORTS)
    @PermitAll
    public List<EmprestimoG> getEmprestimosPorId(Long id) {
        return getEntidades(EmprestimoG.EMPRESTIMO_POR_ID_DE_USUARIO, new Object[]{id});

    }

    @TransactionAttribute(SUPPORTS)
    @PermitAll
    public EmprestimoG getEmprestimo(String status) {
        return super.getEntidade(EmprestimoG.EMPRESTIMO_POR_STATUS, new Object[]{status});
    }

    @TransactionAttribute(SUPPORTS)
    @PermitAll
    public EmprestimoG criar() {
        return new EmprestimoG();
    }
}
