package servico;

import entidade.AlunoG;
import excecao.ExcecaoNegocio;
import java.util.List;
import javax.annotation.security.PermitAll;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import static javax.ejb.TransactionAttributeType.REQUIRED;
import static javax.ejb.TransactionAttributeType.SUPPORTS;
import javax.ejb.TransactionManagement;
import static javax.ejb.TransactionManagementType.CONTAINER;
import javax.validation.executable.ExecutableType;
import javax.validation.executable.ValidateOnExecution;


@Stateless
@LocalBean
//@DeclareRoles({ADMINISTRADOR, USUARIO})
@TransactionManagement(CONTAINER)
@TransactionAttribute(REQUIRED)
@ValidateOnExecution(type = ExecutableType.NON_GETTER_METHODS)
public class AlunoServico extends Servico<AlunoG> {

    //@RolesAllowed({ADMINISTRADOR})
    public void salvar(AlunoG aluno) throws ExcecaoNegocio {
        checarExistencia(AlunoG.ALUNO_POR_MATRICULA, aluno.getMatricula());
        entityManager.persist(aluno);
    }

    //@RolesAllowed({ADMINISTRADOR})
    public void atualizar(AlunoG aluno) throws ExcecaoNegocio {
//        checarNaoExistencia(AlunoG.ALUNO_POR_ID, new Object[]{aluno.getId()});        
        entityManager.merge(aluno);
        entityManager.flush();
    }

    //@RolesAllowed({ADMINISTRADOR})
    public void remover(AlunoG aluno) throws ExcecaoNegocio {
        aluno = entityManager.merge(aluno);
        if (aluno.isInativo()) {
            entityManager.remove(aluno);
        } else {
            throw new ExcecaoNegocio(ExcecaoNegocio.REMOVER_AUTOR);
        }
    }

    //@RolesAllowed({ADMINISTRADOR})
    public void remover(String cpf) throws ExcecaoNegocio {
        AlunoG aluno = getAluno(cpf);
        remover(aluno);
    }

    @TransactionAttribute(SUPPORTS)
    @PermitAll
    public List<AlunoG> getAlunos() {
        return getEntidades(AlunoG.ALUNOS);
    }

    @TransactionAttribute(SUPPORTS)
    @PermitAll
    public AlunoG getAluno(String mat) {
        return super.getEntidade(AlunoG.ALUNO_POR_MATRICULA, new Object[]{mat});
    }

    @TransactionAttribute(SUPPORTS)
    @PermitAll
    public AlunoG criar() {
        return new AlunoG();
    }
}
