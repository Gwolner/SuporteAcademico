package entidade;

import java.io.Serializable;
import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import org.hibernate.validator.constraints.NotBlank;

@Entity
@Table(name = "TB_FARDAMENTO")
@Access(AccessType.FIELD)
@NamedQueries(
        {
             @NamedQuery(
                    name = FardamentoG.FARDAMENTO_POR_ID,
                    query = "SELECT f FROM FardamentoG f WHERE f.aluno.id = ?1"
            ),
            @NamedQuery(
                    name = FardamentoG.FARDAMENTOS,
                    query = "SELECT f FROM FardamentoG f ORDER BY f.id"
            )
        }
)
public class FardamentoG extends Entidade implements Serializable {
    
    public static final String FARDAMENTO_POR_ID = "FardamentoPorId";
    public static final String FARDAMENTOS = "Fardamentos";
    
//    @Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
//    @Column(name = "id_fardamento")
//    private Long idFardamento;

    @Column(name = "quantidade_entregue")
    private int quantidadeEntregue;

    //Cardinalidade Aluno 1 : N FardamentoG
    @ManyToOne(fetch = FetchType.LAZY, optional = true)
//    @JoinColumn(name = "id_aluno", referencedColumnName = "id_aluno")
    @JoinColumn(name = "id_aluno", referencedColumnName = "id_aluno")
    protected AlunoG aluno;

    //Cardinalidade SituacaoG 1 : N FardamentoG
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
//    @JoinColumn(name = "id_situacao", referencedColumnName = "id_situacao")
    @JoinColumn(name = "id_situacao", referencedColumnName = "id")
    protected SituacaoG situacao;

    //Cardinalidade TamanhoG 1 : N FardamentoG
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
//    @JoinColumn(name = "id_tamanho", referencedColumnName = "id_tamanho")
    @JoinColumn(name = "id_tamanho", referencedColumnName = "id")
    protected TamanhoG tamanho;

//    public Long getIdFardamento() {
//        return idFardamento;
//    }
//
//    public void setIdFardamento(Long idFardamento) {
//        this.idFardamento = idFardamento;
//    }

    public int getQuantidadeEntregue() {
        return quantidadeEntregue;
    }

    public void setQuantidadeEntregue(int quantidadeEntregue) {
        this.quantidadeEntregue = quantidadeEntregue;
    }

    public AlunoG getAluno() {
        return aluno;
    }

    public void setAluno(AlunoG aluno) {
        this.aluno = aluno;
    }

    public SituacaoG getSituacao() {
        return situacao;
    }

    public void setSituacao(SituacaoG situacao) {
        this.situacao = situacao;
    }

    public TamanhoG getTamanho() {
        return tamanho;
    }

    public void setTamanho(TamanhoG tamanho) {
        this.tamanho = tamanho;
    }
//
//    @Override
//    public int hashCode() {
//        int hash = 0;
//        hash += (idFardamento != null ? idFardamento.hashCode() : 0);
//        return hash;
//    }
//
//    @Override
//    public boolean equals(Object o) {
//        if (!(o instanceof FardamentoG)) {
//            return false; //Se não for a instância desejada, retorna false;
//        } else {
//            FardamentoG other = (FardamentoG) o;
//            return !((this.idFardamento == null && other.idFardamento != null)
//                    || (this.idFardamento != null
//                    && !this.idFardamento.equals(other.idFardamento)));
//            /* 
//         * Se a sentença for verdadeira, retorna false. 
//         * Se for falsa, retorna true.        
//             */
//        }
//    }
}
