package softwarecorporativo.exemplo.ejb;

import javax.naming.NamingException;
import org.junit.After;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import org.junit.Before;
import org.junit.Test;
import static softwarecorporativo.exemplo.ejb.Teste.container;
import softwarecorporativo.exemplo.ejb.entidade.Aluno;
import softwarecorporativo.exemplo.ejb.entidade.Fardamento;
import softwarecorporativo.exemplo.ejb.entidade.Livro;
import softwarecorporativo.exemplo.ejb.entidade.Situacao;
import softwarecorporativo.exemplo.ejb.entidade.Tamanho;
import softwarecorporativo.exemplo.ejb.servico.FardamentoServico;


public class FardamentoTest extends Teste{
    
    private FardamentoServico fardamentoServico;
   

    @Before
    public void setUp() throws NamingException {
        fardamentoServico = (FardamentoServico) container.getContext().lookup("java:global/classes/ejb/FardamentoServico!softwarecorporativo.exemplo.ejb.servico.FardamentoServico");
    }

    @After
    public void tearDown() {
        fardamentoServico = null;
    }

    
//    //Consultas
//    @Test
//    public void consultarTamanhoPorLetra() {
//        assertEquals(2, tamanhoServico.getTamanhoPorLetra("P%").size());
//    }
    
    //Persistir, Atualziar e Remover  
    
    @Test
    public void persistir() {
        Fardamento fardamento = fardamentoServico.criar();
        
        fardamento.setQuantidadeEntregue(1);
        fardamento.setAluno(criarAluno());
        fardamento.setSituacao(criarSituacao());
        fardamento.setTamanho(criarTamanho());       

        fardamentoServico.persistir(fardamento);
        assertNotNull(fardamento.getIdFardamento());
    }
    
    @Test
    public void atualizar() {
        Fardamento fardamento = fardamentoServico.consultarPorId(new Long(3));
        
        fardamento.setQuantidadeEntregue(2);
        fardamento.setAluno(criarAluno());
        fardamento.setSituacao(criarSituacao());
        fardamento.setTamanho(criarTamanho());
        
        fardamentoServico.atualizar(fardamento);        
        fardamento = fardamentoServico.consultarPorId(new Long(3));   
        
           
        assertEquals(2, fardamento.getQuantidadeEntregue());
    }
    
//    @Test
//    public void remover(){
//        Fardamento fardamento = fardamentoServico.consultarPorId(new Long(2));    
//        fardamentoServico.remover(fardamento);  
//        fardamento = fardamentoServico.consultarPorId(new Long(2));  
//        assertNull(fardamento);
//    }
    
    //Métodos auxiliares
    
    protected Aluno criarAluno(){        
        Aluno aluno = new Aluno();
        aluno.setNomeUsuario("Thomas Edson");
        aluno.setCpf("989.200.730-15");
        aluno.setRg(457253472);
        aluno.setCurso("Quimica");
        aluno.setResponsavel("Abilbo");
        aluno.setContatoResponsavel(911112222L);
        aluno.setTurno("Manha");
        aluno.setMatricula("0915POOP");
        aluno.setEmail("tedson@bol.com");
        
        return aluno;
    }

    protected Situacao criarSituacao(){        
        Situacao situacao = new Situacao();       
        situacao.setDescricaoSituacao("Entr. c/ atraso");
        
        return situacao;
    }
    
    protected Tamanho criarTamanho(){
        Tamanho tamanho = new Tamanho();      
        tamanho.setDescricaoTamanho("GG");
        
        return tamanho;
    }
    
}
