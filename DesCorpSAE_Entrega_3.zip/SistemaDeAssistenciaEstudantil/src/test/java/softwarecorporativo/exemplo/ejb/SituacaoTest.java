package softwarecorporativo.exemplo.ejb;

import javax.ejb.EJBException;
import javax.naming.NamingException;
import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import org.hamcrest.CoreMatchers;
import static org.hamcrest.CoreMatchers.startsWith;
import org.junit.After;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import org.junit.Before;
import org.junit.Test;
import static softwarecorporativo.exemplo.ejb.Teste.container;
import softwarecorporativo.exemplo.ejb.entidade.Livro;
import softwarecorporativo.exemplo.ejb.entidade.Situacao;
import softwarecorporativo.exemplo.ejb.servico.SituacaoServico;



public class SituacaoTest extends Teste{
    
    private SituacaoServico situacaoServico;
    
    @Before
    public void setUp() throws NamingException {
        situacaoServico = (SituacaoServico) container.getContext().lookup("java:global/classes/ejb/SituacaoServico!softwarecorporativo.exemplo.ejb.servico.SituacaoServico");
    }

    @After
    public void tearDown() {
        situacaoServico = null;
    }

    
    //Consultas
    @Test
    public void consultarSituacaoPorDescricao() {
        assertEquals(1, situacaoServico.getSituacaoPorDescricao("N%").size());
    }
    
    //Persistir, Atualziar e Remover  
    
    @Test
    public void persistir() {
        Situacao situacao = situacaoServico.criar();
        
        
        situacao.setDescricaoSituacao("Entr. c/ atraso");
       

        situacaoServico.persistir(situacao);
        assertNotNull(situacao.getIdSituacao());
    }
    
    @Test
    public void atualizar() {
        Situacao situacao = situacaoServico.consultarPorId(new Long(1));
        
        situacao.setDescricaoSituacao("Nao entregue"); 
        
        situacaoServico.atualizar(situacao);        
        situacao = situacaoServico.consultarPorId(new Long(1));   
        
        assertEquals("Nao entregue", situacao.getDescricaoSituacao());
    }
    
    @Test
    public void remover(){
        Situacao situacao = situacaoServico.consultarPorId(new Long(3));    
        situacaoServico.remover(situacao);  
        situacao = situacaoServico.consultarPorId(new Long(3));  
        assertNull(situacao);
    }
    
    //Validation 
    
    @Test(expected = EJBException.class)
    public void atualizarInvalido() {
        Situacao situacao = situacaoServico.consultarPorId(new Long(1));
        situacao.setDescricaoSituacao(
                "Entrrega com atraso pelo DAE"
        );
        try {
            situacaoServico.atualizar(situacao);
        } catch (EJBException ex) {
            assertTrue(ex.getCause() instanceof ConstraintViolationException);
            ConstraintViolationException causa
                = (ConstraintViolationException) ex.getCause();
            for (ConstraintViolation erroValidacao : causa.getConstraintViolations()) {
                assertThat(erroValidacao.getMessage(),CoreMatchers.anyOf(
                    startsWith("A descricao está fora do tamanho suportado."),
                    startsWith("A descricao não pode ser vazia.")
                ));
            }
            
            assertEquals(1, causa.getConstraintViolations().size());
            throw ex;
        }
    }  
}
