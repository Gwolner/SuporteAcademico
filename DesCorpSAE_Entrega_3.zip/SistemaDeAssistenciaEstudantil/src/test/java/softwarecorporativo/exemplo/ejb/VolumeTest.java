package softwarecorporativo.exemplo.ejb;

import javax.ejb.EJBException;
import javax.naming.NamingException;
import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import org.hamcrest.CoreMatchers;
import static org.hamcrest.CoreMatchers.startsWith;
import org.junit.After;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import org.junit.Before;
import org.junit.Test;
import static softwarecorporativo.exemplo.ejb.Teste.container;
import softwarecorporativo.exemplo.ejb.entidade.Livro;
import softwarecorporativo.exemplo.ejb.entidade.Volume;
import softwarecorporativo.exemplo.ejb.servico.VolumeServico;


public class VolumeTest extends Teste{
    
    private VolumeServico volumeServico;
   

    @Before
    public void setUp() throws NamingException {
        volumeServico = (VolumeServico) container.getContext().lookup("java:global/classes/ejb/VolumeServico!softwarecorporativo.exemplo.ejb.servico.VolumeServico");
    }

    @After
    public void tearDown() {
        volumeServico = null;
    }

    
    //Consultas
    @Test
    public void consultarVolumePorDescricao() {
        assertEquals(1, volumeServico.getVolumePorDescricao("%3%").size());
    }
    
    //Persistir, Atualziar e Remover  
    
    @Test
    public void persistir() {
        Volume volume = volumeServico.criar();
        
        volume.setDescricaoVolume("Vol. 4");      

        volumeServico.persistir(volume);
        assertNotNull(volume.getIdVolume());
    }
    
    @Test
    public void atualizar() {
        Volume volume = volumeServico.consultarPorId(new Long(3));
        
        volume.setDescricaoVolume("Vol. 3");
        
        volumeServico.atualizar(volume);        
        volume = volumeServico.consultarPorId(new Long(3));   
        
        assertEquals("Vol. 3", volume.getDescricaoVolume());
    }
    
    @Test
    public void remover(){
        Volume volume = volumeServico.consultarPorId(new Long(5));    
        volumeServico.remover(volume);  
        volume = volumeServico.consultarPorId(new Long(5));  
        assertNull(volume);
    }
    
    //Validation 
    
    @Test(expected = EJBException.class)
    public void atualizarInvalido() {
        Volume volume = volumeServico.consultarPorId(new Long(1));
        volume.setDescricaoVolume(" ");//Descricao inválida
        try {
            volumeServico.atualizar(volume);
        } catch (EJBException ex) {
            assertTrue(ex.getCause() instanceof ConstraintViolationException);
            ConstraintViolationException causa
                = (ConstraintViolationException) ex.getCause();
            for (ConstraintViolation erroValidacao : causa.getConstraintViolations()) {
                assertThat(erroValidacao.getMessage(),CoreMatchers.anyOf(
                    startsWith("A descrição do volume não pode ser vazia.")
                ));
            }
            
            assertEquals(1, causa.getConstraintViolations().size());
            throw ex;
        }
    } 
}
