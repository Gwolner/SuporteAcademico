package softwarecorporativo.exemplo.ejb;

import javax.ejb.EJBException;
import javax.naming.NamingException;
import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import org.hamcrest.CoreMatchers;
import static org.hamcrest.CoreMatchers.startsWith;
import org.junit.After;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import org.junit.Before;
import org.junit.Test;
import static softwarecorporativo.exemplo.ejb.Teste.container;
import softwarecorporativo.exemplo.ejb.entidade.Livro;
import softwarecorporativo.exemplo.ejb.entidade.Volume;
import softwarecorporativo.exemplo.ejb.servico.LivroServico;


public class LivroTest extends Teste{
    
    private LivroServico livroServico;
   

    @Before
    public void setUp() throws NamingException {
        livroServico = (LivroServico) container.getContext().lookup("java:global/classes/ejb/LivroServico!softwarecorporativo.exemplo.ejb.servico.LivroServico");
    }

    @After
    public void tearDown() {
        livroServico = null;
    }

    
    //Consultas
    @Test
    public void consultarLivroPorNome() {
        assertEquals(2, livroServico.getLivroPorNome("Introd%").size());
    }
    
    //Persistir, Atualziar e Remover  
    
    @Test
    public void persistir() {
        Livro livro = livroServico.criar();
        
        livro.setTitulo("Java: Como Programar");
        livro.setAutor("Harvey Deitel");
        livro.setMateria("LPOO");
        livro.setIsbn(9781666123123L);
        livro.setQuantidade(10);
        livro.setVolume(criarVolume());       

        livroServico.persistir(livro);
        assertNotNull(livro.getIdLivro());
    }
    
    @Test
    public void atualizar() {
        Livro livro = livroServico.consultarPorId(new Long(5));
        Long novoIsbn = 9781478985689L;
        
        livro.setMateria("Fisica");
        livro.setTitulo("A Quantica e a Realidade");
        livro.setAutor("Edmario Sebroso");
        livro.setQuantidade(3);
        livro.setIsbn(novoIsbn);
        
        livroServico.atualizar(livro);        
        livro = livroServico.consultarPorId(new Long(5));   
        
        assertEquals("Fisica", livro.getMateria());
        assertEquals("A Quantica e a Realidade", livro.getTitulo()); 
        assertEquals("Edmario Sebroso", livro.getAutor()); 
        assertEquals(3, livro.getQuantidade()); 
        assertEquals(novoIsbn, livro.getIsbn()); 
    }
    
    @Test
    public void remover(){
        Livro livro = livroServico.consultarPorId(new Long(7));    
        livroServico.remover(livro);  
        livro = livroServico.consultarPorId(new Long(7));  
        assertNull(livro);
    }
    
    //Validation 
    
    @Test(expected = EJBException.class)
    public void atualizarInvalido() {
        Livro livro = livroServico.consultarPorId(new Long(1));
        livro.setAutor(" ");//Autor inválido
        try {
            livroServico.atualizar(livro);
        } catch (EJBException ex) {
            assertTrue(ex.getCause() instanceof ConstraintViolationException);
            ConstraintViolationException causa
                = (ConstraintViolationException) ex.getCause();
            for (ConstraintViolation erroValidacao : causa.getConstraintViolations()) {
                assertThat(erroValidacao.getMessage(),CoreMatchers.anyOf(
                    startsWith("Autor não informado.")
                ));
            }
            
            assertEquals(1, causa.getConstraintViolations().size());
            throw ex;
        }
    }
    
    //Metodo auxiliar
    protected Volume criarVolume(){
        Volume volume = new Volume();
        volume.setDescricaoVolume("Vol. 4");
        
        return volume;
    }
}
