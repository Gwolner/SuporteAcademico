package softwarecorporativo.exemplo.ejb;

import javax.ejb.EJBException;
import javax.naming.NamingException;
import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import org.hamcrest.CoreMatchers;
import static org.hamcrest.CoreMatchers.startsWith;
import org.junit.After;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import org.junit.Before;
import org.junit.Test;
import static softwarecorporativo.exemplo.ejb.Teste.container;
import softwarecorporativo.exemplo.ejb.entidade.Emprestimo;
import softwarecorporativo.exemplo.ejb.entidade.Livro;
import softwarecorporativo.exemplo.ejb.servico.EmprestimoServico;


public class EmprestimoTest extends Teste{
    
    private EmprestimoServico emprestimoServico;
   

    @Before
    public void setUp() throws NamingException {
        emprestimoServico = (EmprestimoServico) container.getContext().lookup("java:global/classes/ejb/EmprestimoServico!softwarecorporativo.exemplo.ejb.servico.EmprestimoServico");
    }

    @After
    public void tearDown() {
        emprestimoServico = null;
    }

    
//    //Consultas
//    @Test
//    public void consultarTamanhoPorLetra() {
//        assertEquals(2, tamanhoServico.getTamanhoPorLetra("P%").size());
//    }
    
    //Persistir, Atualziar e Remover  
    
    @Test
    public void persistir() {
        Emprestimo emprestimo = emprestimoServico.criar();
        
        emprestimo.setStatus("Teste");       

        emprestimoServico.persistir(emprestimo);
        assertNotNull(emprestimo.getIdEmprestimo());
    }
    
    @Test
    public void atualizar() {
        Emprestimo emprestimo = emprestimoServico.consultarPorId(new Long(6));
        
        emprestimo.setStatus("Emprestado");
        
        emprestimoServico.atualizar(emprestimo);        
        emprestimo = emprestimoServico.consultarPorId(new Long(6));   
        
        assertEquals("Emprestado", emprestimo.getStatus());
    }
    
    @Test
    public void remover(){
        Emprestimo emprestimo = emprestimoServico.consultarPorId(new Long(11));    
        emprestimoServico.remover(emprestimo);  
        emprestimo = emprestimoServico.consultarPorId(new Long(11));  
        assertNull(emprestimo);
    }
    
    //Validation 
    
    @Test(expected = EJBException.class)
    public void atualizarInvalido() {
        Emprestimo emprestimo = emprestimoServico.consultarPorId(new Long(1));
        emprestimo.setStatus(" ");//Status inválido
        try {
            emprestimoServico.atualizar(emprestimo);
        } catch (EJBException ex) {
            assertTrue(ex.getCause() instanceof ConstraintViolationException);
            ConstraintViolationException causa
                = (ConstraintViolationException) ex.getCause();
            for (ConstraintViolation erroValidacao : causa.getConstraintViolations()) {
                assertThat(erroValidacao.getMessage(),CoreMatchers.anyOf(
                    startsWith("Status não pode ser vazio.")
                ));
            }
            
            assertEquals(1, causa.getConstraintViolations().size());
            throw ex;
        }
    }
}
