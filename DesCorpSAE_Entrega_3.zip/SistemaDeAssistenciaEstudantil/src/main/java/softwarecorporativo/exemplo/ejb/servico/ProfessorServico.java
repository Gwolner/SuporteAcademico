package softwarecorporativo.exemplo.ejb.servico;

import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.validation.executable.ExecutableType;
import javax.validation.executable.ValidateOnExecution;
import softwarecorporativo.exemplo.ejb.entidade.Bolsa;
import softwarecorporativo.exemplo.ejb.entidade.Professor;


@Stateless(name = "ejb/ProfessorServico")
@LocalBean
@ValidateOnExecution(type = ExecutableType.ALL)
public class ProfessorServico extends Servico<Professor>{
    
    @PostConstruct
    public void init() {
        super.setClasse(Professor.class);
    }
 
    @Override
    public Professor criar() {
        return new Professor();
    }
    
    @TransactionAttribute(TransactionAttributeType.SUPPORTS)
    public List<Professor> getProfessorPorNome(String nome) {
        return super.consultarEntidades(new Object[] {nome}, Professor.PROFESSOR_POR_NOME);
    }
    
}
