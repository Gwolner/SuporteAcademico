package softwarecorporativo.exemplo.ejb.servico;

import javax.annotation.PostConstruct;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.validation.executable.ExecutableType;
import javax.validation.executable.ValidateOnExecution;
import softwarecorporativo.exemplo.ejb.entidade.Aluno;
import softwarecorporativo.exemplo.ejb.entidade.Fardamento;

@Stateless(name = "ejb/FardamentoServico")
@LocalBean
@ValidateOnExecution(type = ExecutableType.ALL)
public class FardamentoServico extends Servico<Fardamento>{
    
    @PostConstruct
    public void init() {
        super.setClasse(Fardamento.class);
    }
 
    @Override
    public Fardamento criar() {
        return new Fardamento();
    }
    
}
