package softwarecorporativo.exemplo.ejb.servico;

import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.validation.executable.ExecutableType;
import javax.validation.executable.ValidateOnExecution;
import softwarecorporativo.exemplo.ejb.entidade.Bolsa;


@Stateless(name = "ejb/BolsaServico")
@LocalBean
@ValidateOnExecution(type = ExecutableType.ALL)
public class BolsaServico extends Servico<Bolsa>{
    
    @PostConstruct
    public void init() {
        super.setClasse(Bolsa.class);
    }
 
    @Override
    public Bolsa criar() {
        return new Bolsa();
    }
    
    @TransactionAttribute(TransactionAttributeType.SUPPORTS)
    public List<Bolsa> getBolsaPorNome(String nome) {
        return super.consultarEntidades(new Object[] {nome}, Bolsa.BOLSA_POR_NOME);
    }
    
}
