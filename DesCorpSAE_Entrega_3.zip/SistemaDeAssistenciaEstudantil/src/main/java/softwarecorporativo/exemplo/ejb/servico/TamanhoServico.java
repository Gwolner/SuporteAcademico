package softwarecorporativo.exemplo.ejb.servico;

import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.validation.executable.ExecutableType;
import javax.validation.executable.ValidateOnExecution;
import softwarecorporativo.exemplo.ejb.entidade.Tamanho;


@Stateless(name = "ejb/TamanhoServico")
@LocalBean
@ValidateOnExecution(type = ExecutableType.ALL)
public class TamanhoServico extends Servico<Tamanho>{
    
    @PostConstruct
    public void init() {
        super.setClasse(Tamanho.class);
    }
 
    @Override
    public Tamanho criar() {
        return new Tamanho();
    }
    
    @TransactionAttribute(TransactionAttributeType.SUPPORTS)
    public List<Tamanho> getTamanhoPorLetra(String letra) {
        return super.consultarEntidades(new Object[] {letra}, Tamanho.POR_LETRA);
    }
}
