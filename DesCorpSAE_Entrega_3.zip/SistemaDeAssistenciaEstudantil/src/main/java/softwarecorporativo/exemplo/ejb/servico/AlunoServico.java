package softwarecorporativo.exemplo.ejb.servico;

import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.validation.executable.ExecutableType;
import javax.validation.executable.ValidateOnExecution;
import softwarecorporativo.exemplo.ejb.entidade.Aluno;


@Stateless(name = "ejb/AlunoServico")
@LocalBean
@ValidateOnExecution(type = ExecutableType.ALL)
public class AlunoServico extends Servico<Aluno>{
    
    @PostConstruct
    public void init() {
        super.setClasse(Aluno.class);
    }
 
    @Override
    public Aluno criar() {
        return new Aluno();
    }
    
    @TransactionAttribute(TransactionAttributeType.SUPPORTS)
    public List<Aluno> getAlunoPorNome(String nome) {
        return super.consultarEntidades(new Object[] {nome}, Aluno.ALUNO_POR_NOME);
    }
    
}
