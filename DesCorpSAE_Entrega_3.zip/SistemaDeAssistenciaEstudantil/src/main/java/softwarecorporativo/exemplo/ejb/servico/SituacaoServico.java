package softwarecorporativo.exemplo.ejb.servico;

import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.validation.executable.ExecutableType;
import javax.validation.executable.ValidateOnExecution;
import softwarecorporativo.exemplo.ejb.entidade.Bolsa;
import softwarecorporativo.exemplo.ejb.entidade.Situacao;
import softwarecorporativo.exemplo.ejb.entidade.Tamanho;


@Stateless(name = "ejb/SituacaoServico")
@LocalBean
@ValidateOnExecution(type = ExecutableType.ALL)
public class SituacaoServico extends Servico<Situacao>{
    
    @PostConstruct
    public void init() {
        super.setClasse(Situacao.class);
    }
 
    @Override
    public Situacao criar() {
        return new Situacao();
    }
    
    @TransactionAttribute(TransactionAttributeType.SUPPORTS)
    public List<Situacao> getSituacaoPorDescricao(String nome) {
        return super.consultarEntidades(new Object[] {nome}, Situacao.SITUACAO_POR_DESCRICAO);
    }
}
