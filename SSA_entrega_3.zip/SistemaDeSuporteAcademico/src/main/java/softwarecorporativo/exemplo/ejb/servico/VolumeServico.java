package softwarecorporativo.exemplo.ejb.servico;

import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.validation.executable.ExecutableType;
import javax.validation.executable.ValidateOnExecution;
import softwarecorporativo.exemplo.ejb.entidade.Bolsa;
import softwarecorporativo.exemplo.ejb.entidade.Volume;


@Stateless(name = "ejb/VolumeServico")
@LocalBean
@ValidateOnExecution(type = ExecutableType.ALL)
public class VolumeServico extends Servico<Volume>{
    
    @PostConstruct
    public void init() {
        super.setClasse(Volume.class);
    }
 
    @Override
    public Volume criar() {
        return new Volume();
    }
    
    @TransactionAttribute(TransactionAttributeType.SUPPORTS)
    public List<Volume> getVolumePorDescricao(String nome) {
        return super.consultarEntidades(new Object[] {nome}, Volume.VOLUME_POR_DESCRICAO);
    }
    
}
