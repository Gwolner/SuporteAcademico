package softwarecorporativo.exemplo.ejb.servico;

import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.validation.executable.ExecutableType;
import javax.validation.executable.ValidateOnExecution;
import softwarecorporativo.exemplo.ejb.entidade.Bolsa;
import softwarecorporativo.exemplo.ejb.entidade.Livro;


@Stateless(name = "ejb/LivroServico")
@LocalBean
@ValidateOnExecution(type = ExecutableType.ALL)
public class LivroServico extends Servico<Livro>{
    
    @PostConstruct
    public void init() {
        super.setClasse(Livro.class);
    }
 
    @Override
    public Livro criar() {
        return new Livro();
    }
    
@TransactionAttribute(TransactionAttributeType.SUPPORTS)
    public List<Livro> getLivroPorNome(String nome) {
        return super.consultarEntidades(new Object[] {nome}, Livro.LIVRO_POR_NOME);
    }
    
}
