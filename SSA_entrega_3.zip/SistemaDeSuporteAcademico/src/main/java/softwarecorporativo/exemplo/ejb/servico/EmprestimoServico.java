/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package softwarecorporativo.exemplo.ejb.servico;

import javax.annotation.PostConstruct;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.validation.executable.ExecutableType;
import javax.validation.executable.ValidateOnExecution;
import softwarecorporativo.exemplo.ejb.entidade.Emprestimo;

@Stateless(name = "ejb/EmprestimoServico")
@LocalBean
@ValidateOnExecution(type = ExecutableType.ALL)
public class EmprestimoServico extends Servico<Emprestimo>{
    
    @PostConstruct
    public void init() {
        super.setClasse(Emprestimo.class);
    }
 
    @Override
    public Emprestimo criar() {
        return new Emprestimo();
    }
    
}
