package softwarecorporativo.exemplo.ejb;

import javax.ejb.EJBException;
import javax.naming.NamingException;
import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import org.hamcrest.CoreMatchers;
import static org.hamcrest.CoreMatchers.startsWith;
import org.junit.After;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import org.junit.Before;
import org.junit.Test;
import static softwarecorporativo.exemplo.ejb.Teste.container;
import softwarecorporativo.exemplo.ejb.entidade.Bolsa;
import softwarecorporativo.exemplo.ejb.entidade.Livro;
import softwarecorporativo.exemplo.ejb.servico.BolsaServico;


public class BolsaTest extends Teste{
    
    private BolsaServico bolsaServico;
   

    @Before
    public void setUp() throws NamingException {
        bolsaServico = (BolsaServico) container.getContext().lookup("java:global/classes/ejb/BolsaServico!softwarecorporativo.exemplo.ejb.servico.BolsaServico");
    }

    @After
    public void tearDown() {
        bolsaServico = null;
    }

    
    //Consultas
    @Test
    public void consultarBolsaPorNome() {
        assertEquals(2, bolsaServico.getBolsaPorNome("BIA").size());
    }
    
    //Persistir, Atualziar e Remover  
    
    @Test
    public void persistir() {
        Bolsa bolsa = bolsaServico.criar();
        
        bolsa.setNomeBolsa("PIBIC");
        bolsa.setTipo("Pesquisa");
        bolsa.setValor(0.00);       

        bolsaServico.persistir(bolsa);
        assertNotNull(bolsa.getIdBolsa());
    }
    
    @Test
    public void atualizar() {
        Bolsa bolsa = bolsaServico.consultarPorId(new Long(12));
        Double novoValor = 496.00;
        
        bolsa.setNomeBolsa("Estagiario Superior");
        bolsa.setTipo("Estagio");
        bolsa.setValor(novoValor);
        
        bolsaServico.atualizar(bolsa);        
        bolsa = bolsaServico.consultarPorId(new Long(12));   
        
        assertEquals("Estagiario Superior", bolsa.getNomeBolsa());      
        assertEquals("Estagio", bolsa.getTipo());
        assertEquals(novoValor, bolsa.getValor()); 
    }
    
    @Test
    public void remover(){
        Bolsa bolsa = bolsaServico.consultarPorId(new Long(15));    
        bolsaServico.remover(bolsa);  
        bolsa = bolsaServico.consultarPorId(new Long(15));  
        assertNull(bolsa);
    }
    
    //Validation 
    
    @Test(expected = EJBException.class)
    public void atualizarInvalido() {
        Bolsa bolsa = bolsaServico.consultarPorId(new Long(1));
        bolsa.setNomeBolsa(" ");//Nome inválido
        try {
            bolsaServico.atualizar(bolsa);
        } catch (EJBException ex) {
            assertTrue(ex.getCause() instanceof ConstraintViolationException);
            ConstraintViolationException causa
                = (ConstraintViolationException) ex.getCause();
            for (ConstraintViolation erroValidacao : causa.getConstraintViolations()) {
                assertThat(erroValidacao.getMessage(),CoreMatchers.anyOf(
                    startsWith("O nome da bolsa não foi informado.")
                ));
            }
            
            assertEquals(1, causa.getConstraintViolations().size());
            throw ex;
        }
    } 
}
