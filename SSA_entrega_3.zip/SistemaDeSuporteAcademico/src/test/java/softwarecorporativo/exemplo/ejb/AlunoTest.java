package softwarecorporativo.exemplo.ejb;

import javax.ejb.EJBException;
import javax.naming.NamingException;
import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import org.hamcrest.CoreMatchers;
import static org.hamcrest.CoreMatchers.startsWith;
import org.junit.After;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import org.junit.Before;
import org.junit.Test;
import static softwarecorporativo.exemplo.ejb.Teste.container;
import softwarecorporativo.exemplo.ejb.entidade.Aluno;
import softwarecorporativo.exemplo.ejb.servico.AlunoServico;


public class AlunoTest extends Teste{
    
    private AlunoServico alunoServico;
   

    @Before
    public void setUp() throws NamingException {
        alunoServico = (AlunoServico) container.getContext().lookup("java:global/classes/ejb/AlunoServico!softwarecorporativo.exemplo.ejb.servico.AlunoServico");
    }

    @After
    public void tearDown() {
        alunoServico = null;
    }

    
    //Consultas
    @Test
    public void consultarAlunoPorNome() {
        assertEquals(1, alunoServico.getAlunoPorNome("%Wayne").size());
    }
    
    //Persistir, Atualziar e Remover  
    
    @Test
    public void persistir() {
        Aluno aluno = alunoServico.criar();
        
        aluno.setNomeUsuario("Thomas Edson");
        aluno.setCpf("989.200.730-15");
        aluno.setRg(457253472);
        aluno.setCurso("Quimica");
        aluno.setResponsavel("Abilbo");
        aluno.setContatoResponsavel(911112222L);
        aluno.setTurno("Manha");
        aluno.setMatricula("0915POOP");
        aluno.setEmail("tedson@bol.com");       

        alunoServico.persistir(aluno);
        assertNotNull(aluno.getIdUsuario());
    }
    
    @Test
    public void atualizar() {
        Aluno aluno = alunoServico.consultarPorId(new Long(5));
        String novoNome = "Alfredo Gothan";
        String novoCurso = "TADS";
        Long novoContato = 81911112222L;        
        String novoTurno = "Noite";
        String novaMatricula = "2017OPOP";
        String novoCpf = "148.215.630-02";
        String novoEmail = "alfredinho@gmail.com";
                
        aluno.setNomeUsuario(novoNome);
        aluno.setCurso(novoCurso);
        aluno.setContatoResponsavel(novoContato);
        aluno.setTurno(novoTurno);
        aluno.setMatricula(novaMatricula);
        aluno.setEmail(novoEmail);
        aluno.setCpf(novoCpf);
        
        alunoServico.atualizar(aluno);        
        aluno = alunoServico.consultarPorId(new Long(5));   
        
        assertEquals(novoNome, aluno.getNomeUsuario());      
        assertEquals(novoCurso, aluno.getCurso());   
        assertEquals(novoContato, aluno.getContatoResponsavel());   
        assertEquals(novoTurno, aluno.getTurno());   
        assertEquals(novaMatricula, aluno.getMatricula());   
        assertEquals(novoCpf, aluno.getCpf());   
        assertEquals(novoEmail, aluno.getEmail());
    }
    
    @Test
    public void remover(){
        Aluno aluno = alunoServico.consultarPorId(new Long(10));    
        alunoServico.remover(aluno);  
        aluno = alunoServico.consultarPorId(new Long(10));  
        assertNull(aluno);
    }
    
    //Validation 
    
    @Test(expected = EJBException.class)
    public void atualizarInvalido() {
        Aluno aluno = alunoServico.consultarPorId(new Long(1));
        aluno.setCpf("00011100022");//CPF inválido
        try {
            alunoServico.atualizar(aluno);
        } catch (EJBException ex) {
            assertTrue(ex.getCause() instanceof ConstraintViolationException);
            ConstraintViolationException causa
                = (ConstraintViolationException) ex.getCause();
            for (ConstraintViolation erroValidacao : causa.getConstraintViolations()) {
                assertThat(erroValidacao.getMessage(),CoreMatchers.anyOf(
                    startsWith(
                        "CPF com formato inválido. Deve ser XXX.XXX.XXX-XX."
                    )
                ));
            }
            
            assertEquals(1, causa.getConstraintViolations().size());
            throw ex;
        }
    }
}
