package softwarecorporativo.exemplo.ejb;

import javax.ejb.EJBException;
import javax.naming.NamingException;
import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import org.hamcrest.CoreMatchers;
import static org.hamcrest.CoreMatchers.startsWith;
import org.junit.After;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import org.junit.Before;
import org.junit.Test;
import static softwarecorporativo.exemplo.ejb.Teste.container;
import softwarecorporativo.exemplo.ejb.entidade.Livro;
import softwarecorporativo.exemplo.ejb.entidade.Tamanho;
import softwarecorporativo.exemplo.ejb.servico.TamanhoServico;


public class TamanhoTest extends Teste{
    
    private TamanhoServico tamanhoServico;
    //private FardamentoServico fardamentoServico;
   

    @Before
    public void setUp() throws NamingException {
        tamanhoServico = (TamanhoServico) container.getContext().lookup("java:global/classes/ejb/TamanhoServico!softwarecorporativo.exemplo.ejb.servico.TamanhoServico");
        //fardamentoServico = (FardamentoServico) container.getContext().lookup("java:global/classes/ejb/FardamentoServico!softwarecorporativo.exemplo.ejb.servico.FardamentoServico");
    }

    @After
    public void tearDown() {
        tamanhoServico = null;
    }

    
    //Consultas
    @Test
    public void consultarTamanhoPorLetra() {
        assertEquals(2, tamanhoServico.getTamanhoPorLetra("P%").size());
    }
    
    //Persistir, Atualziar e Remover  
    
    @Test
    public void persistir() {
        Tamanho tamanho = tamanhoServico.criar();
        
        
        tamanho.setDescricaoTamanho("GG");

        tamanhoServico.persistir(tamanho);
        assertNotNull(tamanho.getIdTamanho());
    }
    
    @Test
    public void atualizar() {
        Tamanho tamanho = tamanhoServico.consultarPorId(new Long(3));
        
        tamanho.setDescricaoTamanho("M");
        
        tamanhoServico.atualizar(tamanho);        
        tamanho = tamanhoServico.consultarPorId(new Long(3));   
        
        assertEquals("M", tamanho.getDescricaoTamanho());
    }
    
    @Test
    public void remover(){
        Tamanho tamanho = tamanhoServico.consultarPorId(new Long(5));    
        tamanhoServico.remover(tamanho);  
        tamanho = tamanhoServico.consultarPorId(new Long(5));  
        assertNull(tamanho);
    }
    
    //Validation 
    
    @Test(expected = EJBException.class)
    public void atualizarInvalido() {
        Tamanho tamanho = tamanhoServico.consultarPorId(new Long(1));
        tamanho.setDescricaoTamanho("XXGG");//Descricao inválida
        try {
            tamanhoServico.atualizar(tamanho);
        } catch (EJBException ex) {
            assertTrue(ex.getCause() instanceof ConstraintViolationException);
            ConstraintViolationException causa
                = (ConstraintViolationException) ex.getCause();
            for (ConstraintViolation erroValidacao : causa.getConstraintViolations()) {
                assertThat(erroValidacao.getMessage(),CoreMatchers.anyOf(
                    startsWith("Descrição de tamanho fora do formato da Regex.")
                ));
            }
            
            assertEquals(1, causa.getConstraintViolations().size());
            throw ex;
        }
    }    
}
