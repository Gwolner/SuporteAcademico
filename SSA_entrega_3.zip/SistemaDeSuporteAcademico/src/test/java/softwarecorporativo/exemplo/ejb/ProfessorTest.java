package softwarecorporativo.exemplo.ejb;

import javax.ejb.EJBException;
import javax.naming.NamingException;
import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import org.hamcrest.CoreMatchers;
import static org.hamcrest.CoreMatchers.startsWith;
import org.junit.After;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import org.junit.Before;
import org.junit.Test;
import static softwarecorporativo.exemplo.ejb.Teste.container;
import softwarecorporativo.exemplo.ejb.entidade.Aluno;
import softwarecorporativo.exemplo.ejb.entidade.Professor;
import softwarecorporativo.exemplo.ejb.servico.ProfessorServico;


public class ProfessorTest extends Teste{
    
    private ProfessorServico professorServico;
   

    @Before
    public void setUp() throws NamingException {
        professorServico = (ProfessorServico) container.getContext().lookup("java:global/classes/ejb/ProfessorServico!softwarecorporativo.exemplo.ejb.servico.ProfessorServico");
    }

    @After
    public void tearDown() {
        professorServico = null;
    }

    
    //Consultas
    @Test
    public void consultarProfessorPorNome() {
        assertEquals(1, professorServico.getProfessorPorNome("Abner%").size());
    }
    
    //Persistir, Atualziar e Remover  
    
    @Test
    public void persistir() {
        Professor professor = professorServico.criar();
        
        professor.setNomeUsuario("Murilo Murilison");
        professor.setCpf("822.732.580-70");
        professor.setRg(438713588);
        professor.setDepartamento("DADT");
        professor.setRamal(2530L);
        professor.setSiape(3064587);       

        professorServico.persistir(professor);
        assertNotNull(professor.getIdUsuario());
    }
    
    @Test
    public void atualizar() {
        Professor professor = professorServico.consultarPorId(new Long(16));
        String novoDepartamento = "DEN";
        Long novoRamal = 21252530L;
        int novoSiape = 3064632;
        
        professor.setDepartamento(novoDepartamento);
        professor.setRamal(novoRamal);
        professor.setSiape(novoSiape);
        
        professorServico.atualizar(professor);        
        professor = professorServico.consultarPorId(new Long(16));   
        
        assertEquals(novoDepartamento, professor.getDepartamento());      
        assertEquals(novoRamal, professor.getRamal());   
        assertEquals(novoSiape, professor.getSiape());
    }
    
    @Test
    public void remover(){
        Professor professor = professorServico.consultarPorId(new Long(11));    
        professorServico.remover(professor);  
        professor = professorServico.consultarPorId(new Long(11));  
        assertNull(professor);
    }
    
    //Validation 
    
    @Test(expected = EJBException.class)
    public void atualizarInvalido() {
        Professor professor = professorServico.consultarPorId(new Long(18));
        professor.setDepartamento(" ");//Departamento inválido
        try {
            professorServico.atualizar(professor);
        } catch (EJBException ex) {
            assertTrue(ex.getCause() instanceof ConstraintViolationException);
            ConstraintViolationException causa
                = (ConstraintViolationException) ex.getCause();
            for (ConstraintViolation erroValidacao : causa.getConstraintViolations()) {
                assertThat(erroValidacao.getMessage(),CoreMatchers.anyOf(
                    startsWith("Departamento não pode estar vazio.")
                ));
            }
            
            assertEquals(1, causa.getConstraintViolations().size());
            throw ex;
        }
    }
}
